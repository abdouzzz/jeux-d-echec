/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeux.d.échecs;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Utilisateur
 */
public class VisuGrille extends JComponent implements ActionListener{
private JButton visueGrille[][];
private final ImageIcon imgTourB = new ImageIcon(getClass().getResource("TB.gif"));
private final ImageIcon      imgTourN = new ImageIcon(getClass().getResource("TN.gif"));
private final ImageIcon imgCavalierB=new ImageIcon(getClass().getResource("CB.gif"));
private final ImageIcon imgCavalierN =new ImageIcon(getClass().getResource("CN.gif"));
private final ImageIcon imgFouB =new ImageIcon(getClass().getResource("FB.gif"));
private final ImageIcon  imgFouN =new ImageIcon(getClass().getResource("FN.gif"));
private final ImageIcon    imgRoiB = new ImageIcon(getClass().getResource("RB.gif"));
private final ImageIcon   imgRoiN = new ImageIcon(getClass().getResource("RN.gif"));
private final ImageIcon    imgDameB = new ImageIcon(getClass().getResource("DB.gif"));
private final ImageIcon   imgDameN =new ImageIcon(getClass().getResource("DN.gif"));
private final ImageIcon   imgPionB =new ImageIcon(getClass().getResource("PB.gif"));
private final ImageIcon   imgPionN =new ImageIcon(getClass().getResource("PN.gif"));
 
 String [][]pieces; 


@Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public JButton getVisu(int i , int j){
        return visueGrille [i][j];
    }
    public VisuGrille() {    
        this.pieces = new String[][]{{"NT","NC","NF","ND","NR","NF","NC","NT"}, {"NP","NP","NP","NP","NP","NP","NP","NP"}, {null,null,null,null,null,null,null,null}, {null,null,null,null,null,null,null,null}, {null,null,null,null,null,null,null,null}, {null,null,null,null,null,null,null,null}, {"BP","BP","BP","BP","BP","BP","BP","BP"}, {"BT","BC","BF","BD","BR","BF","BC","BT"}};
        visueGrille = new JButton[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                 visueGrille[i][j] = new JButton();
                 visueGrille[i][j].addActionListener(this);
            }
                
            }
        
        
       
    }
    
   
    
}
